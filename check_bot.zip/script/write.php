<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Параметры подключения к базе данных
$host = 'localhost'; // Адрес базы данных
$dbname = ''; // Имя вашей базы данных
$username = ''; // Имя пользователя базы данных
$password = ''; // Пароль пользователя базы данных

// Подключение к базе данных
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Ошибка подключения: " . $e->getMessage();
    exit;
}

// Получение текущей даты и времени
$currentDate = date('Y-m-d H:i:s');

// Получение IP-адреса
$ipAddress = $_SERVER['REMOTE_ADDR'] ?? 'Unknown IP';

// Получение User-Agent
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown User-Agent';

// Запись данных в базу данных
$sql = "INSERT INTO user_ip_data (ip_address, user_agent, date_time) VALUES (:ip_address, :user_agent, :date_time)";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':ip_address', $ipAddress);
$stmt->bindParam(':user_agent', $userAgent);
$stmt->bindParam(':date_time', $currentDate);

if ($stmt->execute()) {
    echo 'Данные успешно записаны в базу данных.';
} else {
    echo 'Ошибка записи в базу данных.';
}
?>
