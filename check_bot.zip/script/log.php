<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Параметры подключения к базе данных
$host = 'localhost'; // Адрес базы данных
$dbname = ''; // Имя вашей базы данных
$username = ''; // Имя пользователя базы данных
$password = ''; // Пароль пользователя базы данных

// Подключение к базе данных
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Ошибка подключения: " . $e->getMessage();
    exit;
}

// Загрузка списка подсетей из файла
$subnetsFile = 'subnets.txt';
if (!file_exists($subnetsFile)) {
    die("Файл с подсетями ($subnetsFile) не найден.");
}
$subnets = file($subnetsFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

/**
 * Проверка, входит ли IP-адрес в любую подсеть из списка.
 */
function ipInAnySubnet($ip, $subnets) {
    foreach ($subnets as $subnet) {
        list($subnetAddress, $prefixLength) = explode('/', $subnet);
        $subnetLong = ip2long($subnetAddress);
        $ipLong = ip2long($ip);
        $mask = ~((1 << (32 - $prefixLength)) - 1);
        if (($ipLong & $mask) === ($subnetLong & $mask)) {
            return $subnet; // Возвращаем совпавшую подсеть
        }
    }
    return false;
}

// Запрос к базе данных для получения всех записей
$sql = "SELECT ip_address, user_agent, date_time FROM user_ip_data";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$logEntries = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Визуализация данных
echo "<h1>Логи пользователей</h1>";
echo "<table border='1' cellpadding='5' cellspacing='0'>";
echo "<tr><th>Дата</th><th>IP-адрес</th><th>User-Agent</th><th>Совпавшая подсеть</th></tr>";

foreach ($logEntries as $entry) {
    $date = $entry['date_time'];
    $ip = $entry['ip_address'];
    $userAgent = $entry['user_agent'];

    // Проверка на принадлежность любой подсети
    $matchedSubnet = ($ip !== 'Unknown IP') ? ipInAnySubnet($ip, $subnets) : false;

    echo "<tr>";
    echo "<td>$date</td>";
    echo "<td>$ip</td>";
    echo "<td>$userAgent</td>";
    echo "<td>" . ($matchedSubnet ? "Да ($matchedSubnet)" : "Нет") . "</td>";
    echo "</tr>";
}

echo "</table>";
?>
